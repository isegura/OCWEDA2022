from dlist import DList


class DList2(DList):
    def remove(self, e: object) -> None:
        """borra la primera ocurrencia de e en la lista.
        No devuelve nada. Modifica la propia lista (self)"""
        ...

    def remove_all(self, e: object) -> None:
        """borra todas las ocurrencias de e en la lista.
        No devuelve nada. Modifica la propia lista (self)"""
        ...

    def getAtRev(self, index: int) -> object:
        """Devuelve el elemento que está en la posición index, pero
         empezando a contar desde el final.
         Por ejemplo. self.getAtRev(0), debería devolver el último elemento de la lista
         , mientras self.getAtRev(len(self)-1) devolverá el primero.
         El método debe comprobar que el índice está en el rango de la lista"""
        ...

    def get_middle(self) -> object:
        """Devuelve el elemento que está en la mista de la lista.
        Si el tamaño es par, el método deberá devolver el elemento en la posición
        len // 2"""
        ...

    def count(self, e: object) -> int:
        """Devuelve el número de veces que e ocurre en la lista"""
        ...

    def is_sorted(self) -> bool:
        """Devuelve True si la lista está ordenada (de menor a mayor) y FAlse eoc"""
        ...

    def remove_duplicates_sorted(self) -> None:
        """Si la lista no está ordenada, no se hace nada.
        Si la lsita está ordenada, se eliminan los duplicados.
        Por ejemplo, en la lista: 1<->1<->2<->2<->2<->3<->4<->4<->4<->4<->5, después de llamar al método,
        la lista deberá contener los elementos: 1<->2<->3<->4<->5"""
        ...

    def remove_duplicates(self) -> None:
        """En este caso, la lista puede estar no ordenada.
        Se eliminan las ocurrencias duplicadas.
        Por ejemplo, lista: 2<->1<->2<->2<->3<->1<->1<->5<->4<->5<->2, la lista después de llamar al método
        contiene los siguientes elementos: 2<->1<->3<->5<->4"""
        ...
    def swap_pairwais(self) -> None:
        """Modifica la lista intercambiando los elementos consecutivos.
        Por ejemplo, lista: 1<->2<->3<->4<->5<->6<->7, después de invocar al método,
        la lista contiene los elementos: 2<->1<->4<->3<->6<->5<->7"""

    def move_last(self) -> None:
        """Modifica la lista moviendo el último elemento al principio de la lista.
        Por ejemplo, l:1<->2<->3<->4<->5<->6, l: 6<->1<->2<->3<->4<->5"""
        ...

    def intersection(self, other: 'DList2') -> 'DList2':
        """Devuelve una nueva lista que es únicamente contiene los elementos
        que están en ambas listas. El método tiene la precondición de que ambas
        listas (self, y other) están ordenadas de forma ascendiente.
        Por ejemplo, self:1<->2<->3<->4<->5<->6, other: 0<->1<->2<->3, output: 1<->2<->3"""
        ...
    def segregate_odd_even(self) -> None:
        """Modifica la lista para que todos los elementos pares
        aparezcan antes que los impares. Ejemplo:
         Ejemplo: self: 17<->15<->8<->12<->10<->5<->4<->1<->7<->6
            self: 8<->12<->10<->4<->6<->17<->15<->5<->1<->7"""
